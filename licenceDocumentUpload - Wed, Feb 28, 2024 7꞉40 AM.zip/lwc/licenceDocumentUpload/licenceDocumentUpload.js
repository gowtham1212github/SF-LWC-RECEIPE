import { LightningElement, wire, track } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import { CurrentPageReference } from 'lightning/navigation';
import USER_ID from '@salesforce/user/Id';
import getPendingAccounts from '@salesforce/apex/ComplianceRecordsController.getComplianceRecords';

export default class PatientDocumentUpload extends LightningElement {
    @track data = [];
    @track columns = [];
    userProfile;

    @wire(getRecord, { recordId: USER_ID, fields: ['User.Profile.Name'] })
    wiredUser({ error, data }) {
        if (data) {
            this.userProfile = getFieldValue(data, 'User.Profile.Name');
            this.setColumns();
        } else if (error) {
            console.error('Error fetching user profile:', error);
        }
    }

    @wire(CurrentPageReference) pageRef;

    

    setColumns() {
        let columnList = [
             { label: 'Profile', type: 'image', fieldName: 'ProfileUrl' },
            { label: 'Type', fieldName: 'Type__c', sortable: true },
            { label: 'Status', fieldName: 'Status__c', sortable: true },
            { label: 'Expiration Date', fieldName: 'Expiration_Date__c', sortable: true, editable: true },
            { label: 'Documents Upload', type: 'fileUpload', fieldName: 'Id', 
                typeAttributes: { acceptedFileFormats: '.jpg,.jpeg,.pdf,.png', fileUploaded: { fieldName: 'IsDocumentComplete__c' } } }
        ];

        if (this.userProfile === '#Custom: Installer Community User - Primary') {	
 
            // Only include Contact Name column if user profile is 'Installer Community User - Primary'
            columnList.splice(1, 0, { label: 'Contact Name', fieldName: 'ContactName', type: 'text' });
        }

        this.columns = columnList;
    }
@wire(getPendingAccounts)
    wiredPendingAccounts({ error, data }) {
        if (data) {
            this.data = data.map(row => ({
                ...row,ContactName: row.Contact__r.Name,
                ProfileUrl: row.Contact__r.Photo__c
            }));
            console.log(JSON.stringify(data));
        } else if (error) {
            console.error('Error fetching compliance records:', error);
        }
    }
    extractImageUrl(richTextField) {
        if (richTextField) {
            const urls = richTextField.split(',');
            if (urls.length > 0) {
                return urls[0]; // Return the first image URL
            }
        }
        return null; // Return null if the rich text field is null or empty
    }

    handleUploadFinished(event) {
        event.stopPropagation();
        console.log('Uploaded files:', JSON.stringify(event.detail.files));
        // Perform any additional processing here
    }
}